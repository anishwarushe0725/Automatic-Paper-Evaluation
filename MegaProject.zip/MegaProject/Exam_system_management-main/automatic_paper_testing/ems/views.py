from django.shortcuts import render

def ems(request):
    return render(request, 'ems.html')  

def about(request):
    return render(request, 'about.html')

def features(request):
    return render(request, 'features.html') 
