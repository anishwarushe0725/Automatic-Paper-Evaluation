from django.urls import path
from .views import ems, about, features  

app_name = 'ems'

urlpatterns = [
    path('about/', about, name='about'),       
    path('features/', features, name='features'),  
    path('', ems, name='ems'),                
]
