import os
import re
import PyPDF2
import nltk
import numpy as np
import torch
from transformers import AutoTokenizer, AutoModel
from nltk.tokenize import sent_tokenize
from nltk.corpus import stopwords
from sklearn.metrics.pairwise import cosine_similarity

import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# Download necessary NLTK resources
nltk.download('punkt', quiet=True)
nltk.download('stopwords', quiet=True)

class SemanticGrader:
    def __init__(self, model_name="sentence-transformers/all-MiniLM-L6-v2"):
        """Initialize the grader with a language model for semantic understanding."""
        self.questions = []
        self.model_answers = []
        self.max_marks = []
        self.stop_words = set(stopwords.words('english'))
        
        # Load model and tokenizer
        print("Loading language model for semantic understanding...")
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name)
        print("Model loaded successfully!")
        
    def add_question(self, question, model_answer, max_marks):
        """Add a question with its model answer and maximum marks."""
        self.questions.append(question)
        self.model_answers.append(model_answer)
        self.max_marks.append(max_marks)
    
    def load_questions_from_array(self, questions_array):
        """Load questions, model answers, and max marks from an array."""
        # Clear existing questions
        self.questions = []
        self.model_answers = []
        self.max_marks = []
        
        # Add each question from the array
        for i, question_data in enumerate(questions_array):
            question_text = question_data.get("question", "")
            model_answer = question_data.get("model_answer", "")
            max_marks = question_data.get("max_marks", 0)
            
            self.add_question(question_text, model_answer, float(max_marks))
            
        return True
    
    def extract_text_from_pdf(self, pdf_path):
        """Extract text from a PDF file."""
        with open(pdf_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            text = ""
            for page in reader.pages:
                text += page.extract_text() + "\n"
        return text
    
    def get_embedding(self, text):
        """Generate sentence embeddings using the transformer model."""
        # Clean and preprocess text
        text = text.replace('\n', ' ').strip()
        if not text:
            return np.zeros(384)  # Return zero vector for empty text
            
        # Tokenize and get model output
        inputs = self.tokenizer(text, padding=True, truncation=True, return_tensors="pt", max_length=512)
        with torch.no_grad():
            outputs = self.model(**inputs)
        
        # Use mean pooling to get sentence embedding
        attention_mask = inputs['attention_mask']
        token_embeddings = outputs.last_hidden_state
        input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
        sum_embeddings = torch.sum(token_embeddings * input_mask_expanded, 1)
        sum_mask = torch.clamp(input_mask_expanded.sum(1), min=1e-9)
        embedding = (sum_embeddings / sum_mask).squeeze().numpy()
        
        return embedding
    
    def split_into_concepts(self, text):
        """Split an answer into individual concepts/statements."""
        # Split into sentences
        sentences = sent_tokenize(text)
        
        # Clean sentences
        sentences = [s.strip() for s in sentences if s.strip()]
        
        return sentences
        
    def semantic_similarity(self, text1, text2):
        """Calculate semantic similarity between two texts using embeddings."""
        embedding1 = self.get_embedding(text1)
        embedding2 = self.get_embedding(text2)
        
        # Compute cosine similarity between the embeddings
        similarity = cosine_similarity([embedding1], [embedding2])[0][0]
        return similarity
    
    def concept_matching(self, model_answer, student_answer):
        """Break down answers into concepts and check how many concepts match."""
        # Split answers into concepts (sentences)
        model_concepts = self.split_into_concepts(model_answer)
        student_concepts = self.split_into_concepts(student_answer)
        
        if not model_concepts or not student_concepts:
            return 0.0
        
        # Matrix to store similarity between each concept pair
        similarity_matrix = np.zeros((len(model_concepts), len(student_concepts)))
        
        # Compute similarity for each pair of concepts
        for i, model_concept in enumerate(model_concepts):
            for j, student_concept in enumerate(student_concepts):
                similarity_matrix[i, j] = self.semantic_similarity(model_concept, student_concept)
        
        # For each model concept, find the best matching student concept
        best_matches = np.max(similarity_matrix, axis=1)
        
        # Average of best matches gives us concept coverage
        concept_coverage = np.mean(best_matches)
        
        return concept_coverage
    
    def factual_accuracy(self, model_answer, student_answer):
        """Evaluate factual accuracy by checking for contradictions."""
        # Get overall semantic similarity
        similarity = self.semantic_similarity(model_answer, student_answer)
        
        # Lower similarity might indicate factual errors
        accuracy = similarity
        
        return accuracy
    
    def grade_answer(self, model_answer, student_answer, max_marks):
        """Grade a student answer based on semantic understanding of the content."""
        if not student_answer.strip():
            return 0.0
            
        # Compute overall semantic similarity
        overall_similarity = self.semantic_similarity(model_answer, student_answer)
        
        # Compute concept coverage
        concept_match = self.concept_matching(model_answer, student_answer)
        
        # Compute factual accuracy
        accuracy = self.factual_accuracy(model_answer, student_answer)
        
        # Calculate final score based on multiple metrics
        score = (
            overall_similarity * 0.4 +  # Overall semantic similarity
            concept_match * 0.4 +       # Concept coverage
            accuracy * 0.2              # Factual accuracy
        ) * max_marks
        
        # Round to nearest 0.5
        score = round(score * 2) / 2
        
        # Ensure score is within bounds
        score = max(0, min(score, max_marks))
        
        return score
    
    def evaluate(self, questions_data, student_answers):
        """Evaluate student answers against questions.
        
        Args:
            questions_data: List of dictionaries containing questions, model answers, and max marks
            student_answers: List of student answers corresponding to each question
            
        Returns:
            Dictionary containing evaluation results
        """
        # Load the questions
        self.load_questions_from_array(questions_data)
        
        # Grade each answer
        scores = []
        detailed_feedback = []
        
        for i in range(len(self.questions)):
            if i < len(student_answers):
                score = self.grade_answer(self.model_answers[i], student_answers[i], self.max_marks[i])
                
                # Generate feedback
                if score >= self.max_marks[i] * 0.8:
                    feedback = "Excellent answer with comprehensive understanding."
                elif score >= self.max_marks[i] * 0.6:
                    feedback = "Good answer with most key concepts covered."
                elif score >= self.max_marks[i] * 0.4:
                    feedback = "Satisfactory answer but missing some important concepts."
                elif score >= self.max_marks[i] * 0.2:
                    feedback = "Below average answer with significant gaps in understanding."
                else:
                    feedback = "Poor answer showing minimal understanding of the topic."
                
                scores.append(score)
                detailed_feedback.append(feedback)
            else:
                scores.append(0)
                detailed_feedback.append("No answer provided")
        
        # Calculate total score
        total_score = sum(scores)
        max_possible = sum(self.max_marks)
        
        # Create a detailed report
        results = {
            'questions': self.questions,
            'model_answers': self.model_answers,
            'student_answers': student_answers,
            'max_marks': self.max_marks,
            'scores': scores,
            'feedback': detailed_feedback,
            'total_score': total_score,
            'max_possible': max_possible,
            'percentage': (total_score/max_possible*100) if max_possible > 0 else 0
        }
        
        return results