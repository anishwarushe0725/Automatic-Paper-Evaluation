import sys
import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from checking import SemanticGrader

from checking import SemanticGrader

def grade_student_submission(questions, student_answers):
    """
    Grade a student submission using the semantic grader.
    
    Args:
        questions: List of dictionaries containing questions, model answers, and max marks
        student_answers: List of student answers corresponding to each question
        
    Returns:
        Dictionary containing evaluation results
    """
    grader = SemanticGrader()
    
    results = grader.evaluate(questions, student_answers)
    
    return results

if __name__ == "__main__":
    questions = [
        {
            "question": "What is the capital of France?",
            "model_answer": "The capital of France is Paris.",
            "max_marks": 5
        },
        {
            "question": "Explain the concept of photosynthesis.",
            "model_answer": "Photosynthesis is the process by which green plants and some other organisms use sunlight to synthesize nutrients from carbon dioxide and water. Photosynthesis in plants generally involves the green pigment chlorophyll and generates oxygen as a byproduct.",
            "max_marks": 10
        }
    ]
    
    student_answers = [
        "Paris is the capital of France.",
        "Photosynthesis is how plants make food using sunlight and water. They also produce oxygen during this process."
    ]
    
    results = grade_student_submission(questions, student_answers)
    
    print(f"Total Score: {results['total_score']}/{results['max_possible']}")
    print(f"Percentage: {results['percentage']:.2f}%")
    
    for i in range(len(results['questions'])):
        print(f"\nQuestion: {results['questions'][i]}")
        print(f"Student Answer: {results['student_answers'][i]}")
        print(f"Score: {results['scores'][i]}/{results['max_marks'][i]}")
        print(f"Feedback: {results['feedback'][i]}")



