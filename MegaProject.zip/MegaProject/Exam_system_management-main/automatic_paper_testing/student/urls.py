from django.urls import path
from .views import *
app_name = 'student'
urlpatterns = [
    path('student_dashboard/', student_dashboard, name='student_dashboard'),
    path('student_exam/', student_exam, name='student_exam'),


    path('upload_pdf/', upload_pdf, name='upload_pdf'),
    path('student_login/', student_login, name='student_login'),
    path('student_register/', student_register, name='student_register'),
    path('student_verify_email/', student_verify_email, name='student_verify_email'),
    path('student_reset_password/<int:id>/', student_reset_password, name='student_reset_password'),
    path('student_verification/', student_verification, name='student_verification'),
    path('student_logout/', student_logout, name='student_logout'),  
]

from django.conf import settings
from django.conf.urls.static import static

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
