from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.units import inch, cm
from io import BytesIO
from django.http import HttpResponse
from datetime import datetime
import os

def generate_question_paper_pdf(data):
    """
    Generate a PDF question paper based on the provided data.
    
    Args:
        data (dict): Dictionary containing all the question paper details
    
    Returns:
        BytesIO: PDF file as a BytesIO object
    """
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=72)
    
    elements = []
    styles = getSampleStyleSheet()
    
    # Add custom styles
    styles.add(ParagraphStyle(name='CenteredTitle', parent=styles['Title'], alignment=1))
    styles.add(ParagraphStyle(name='CenteredHeading', parent=styles['Heading1'], alignment=1, fontSize=14))
    styles.add(ParagraphStyle(name='Normal-Bold', parent=styles['Normal'], fontName='Helvetica-Bold'))
    
    # Create header table
    header_data = [
        [Paragraph(f"<b>{data['college_name']}</b>", styles['CenteredTitle'])],
        [Paragraph(f"<b>{data['exam_type']}</b>", styles['CenteredHeading'])]
    ]
    
    header_table = Table(header_data, colWidths=[450])
    header_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ]))
    elements.append(header_table)
    elements.append(Spacer(1, 0.2*inch))
    
    # Create course information table
    course_data = [
        [Paragraph("<b>Course Code:</b>", styles['Normal-Bold']), Paragraph(data['course_code'], styles['Normal']),
         Paragraph("<b>PRN:</b>", styles['Normal-Bold']), Paragraph("", styles['Normal'])],
        [Paragraph("<b>Course Name:</b>", styles['Normal-Bold']), Paragraph(data['course_name'], styles['Normal']),
         "", ""],
        [Paragraph("<b>Day and Date:</b>", styles['Normal-Bold']), Paragraph(data['exam_date'], styles['Normal']),
         Paragraph("<b>Max Marks:</b>", styles['Normal-Bold']), Paragraph(data['maximum_marks'], styles['Normal'])],
        [Paragraph("<b>Time:</b>", styles['Normal-Bold']), Paragraph(data['exam_time'], styles['Normal']),
         "", ""],
    ]
    
    course_table = Table(course_data, colWidths=[100, 180, 80, 90])
    course_table.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.white),
    ]))
    elements.append(course_table)
    elements.append(Spacer(1, 0.2*inch))
    
    # Instructions
    elements.append(Paragraph("<b>Instructions:</b>", styles['Normal-Bold']))
    instructions = data['instructions'].split('\n')
    for i, instruction in enumerate(instructions):
        elements.append(Paragraph(f"{i+1}. {instruction}", styles['Normal']))
    
    elements.append(Spacer(1, 0.2*inch))
    
    # Questions
    questions = data['questions']
    question_count = 1
    
    for i, question in enumerate(questions):
        # Create a table for the question header
        q_header = [
            [Paragraph(f"Q {question_count} Attempt any two", styles['Normal-Bold'])],
        ]
        q_header_table = Table(q_header, colWidths=[450])
        q_header_table.setStyle(TableStyle([
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ]))
        elements.append(q_header_table)
        
        # Parse the question text to extract sub-questions
        text = question['question']
        sub_questions = text.split("###")
        
        for j, sub_q in enumerate(sub_questions):
            if not sub_q.strip():
                continue
                
            # Extract sub-question letter and text
            if j == 0 and sub_q.strip().startswith('A'):
                sub_q_letter = 'A'
                sub_q_text = sub_q.strip()[1:].strip()
            elif j == 1 and sub_q.strip().startswith('B'):
                sub_q_letter = 'B'
                sub_q_text = sub_q.strip()[1:].strip()
            elif j == 2 and sub_q.strip().startswith('C'):
                sub_q_letter = 'C'
                sub_q_text = sub_q.strip()[1:].strip()
            else:
                sub_q_letter = chr(65 + j)  # A, B, C, etc.
                sub_q_text = sub_q.strip()
            
            # Create a table for each sub-question with marks
            sub_q_table = [
                [
                    Paragraph(f"{sub_q_letter}. {sub_q_text}", styles['Normal']),
                    Paragraph(f"{question['max_marks']}", styles['Normal']),
                    Paragraph(f"CO{j+1}", styles['Normal']),
                    Paragraph(f"{question['max_marks']}", styles['Normal'])
                ]
            ]
            
            sub_q_table_obj = Table(sub_q_table, colWidths=[350, 30, 40, 30])
            sub_q_table_obj.setStyle(TableStyle([
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('GRID', (1, 0), (-1, 0), 0.5, colors.black),
                ('LEFTPADDING', (0, 0), (0, 0), 20),  # Indent the sub-question
            ]))
            elements.append(sub_q_table_obj)
            elements.append(Spacer(1, 0.1*inch))
        
        question_count += 1
        elements.append(Spacer(1, 0.3*inch))
    
    # Build the PDF
    doc.build(elements)
    buffer.seek(0)
    return buffer