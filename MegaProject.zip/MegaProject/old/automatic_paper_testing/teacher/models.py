from django.db import models
from django.contrib.auth.models import User
import uuid

from django.db import models
from django.contrib.auth.models import User

class Teacher(models.Model):
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name="teacher_profile"
    )
    
    enrollment_number = models.CharField(max_length=100, unique=True)
    name = models.CharField(max_length=255,null=False,blank=False)
    department = models.CharField(max_length=255, null=True, blank=True)
    phone_number = models.CharField(max_length=15, null=True, blank=True)
    bio = models.TextField(null=True, blank=True)  # Optional field for teacher bio
    security_key = models.CharField(max_length=255, null=True, blank=True)  # Security key
    is_approved = models.BooleanField(default=False)  # Field for admin approval

    def __str__(self):
        return f"{self.user.email}  ({self.enrollment_number})"

class Exam(models.Model):
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE, null=True, blank=True)
    college_name = models.CharField(max_length=255, default="Unknown College")

    exam_type = models.CharField(max_length=100, default="Regular Exam")

    course_code = models.CharField(max_length=50, null=True, blank=True)

    course_name = models.CharField(max_length=255, null=True, blank=True)

    start_time = models.DateTimeField(null=True, blank=True)
    end_time = models.DateTimeField(null=True, blank=True)
    maximum_marks = models.PositiveIntegerField(default=20)
    instructions = models.TextField(max_length=255, null=True, blank=True)
    
    class ExamStatus(models.TextChoices):
        DRAFT = 'Draft', 'Draft'
        PUBLISHED = 'Published', 'Published'

    status = models.CharField(
        max_length=10,
        choices=ExamStatus.choices,
        default=ExamStatus.DRAFT
    )
    
    exam_date = models.DateField()
    exam_time = models.TimeField(null=True, blank=True)  # Changed from CharField

    def __str__(self):
        return f"{self.exam_type} - {self.course_name} on {self.exam_date.strftime('%d %b %Y') if self.exam_date else 'No Date'}"


class Question(models.Model):
    exam = models.ForeignKey(Exam, related_name="questions", on_delete=models.CASCADE)
    question_text = models.TextField(null=True, blank=True)
    marks = models.PositiveIntegerField(default=1)

    correct_answer = models.TextField(null=True, blank=True)  # Consider JSONField for MCQs

    def __str__(self):
        return self.question_text
